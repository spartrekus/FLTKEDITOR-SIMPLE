
=============
Hello world
=============


= Intro
----------
This  a  very basic editor using FLTK 
It was based on the examples of FLTK




= Compile and Installation
---------------------------------------
To compile:
make 

To install: 
make install
